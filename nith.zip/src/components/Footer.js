import React from 'react'

export const Footer = () => {
    return (
        <div className="Footer">
            <p> Designed and Developed by  👨‍🦱 NithinAlva</p>
        </div>
    )
}
